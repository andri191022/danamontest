# Microsoft.NET.StringTools

This package contains the Microsoft.NET.StringTools assembly which implements common string-related functionality such as weak interning.

At this time, this is primarily an internal implementation detail of MSBuild and Visual Studio and we do not expect other consumers of the package. If you think you might like to use it, please start a discussion at https://github.com/dotnet/msbuild/discussions to let us know your use cases.
