NuGet's understanding of target frameworks.
