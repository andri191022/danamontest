NuGet's core types and interfaces for PackageReference-based restore, such as lock files, assets file and internal restore models.
