NuGet's PackageReference dependency resolver implementation.
