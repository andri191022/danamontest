NuGet's configuration settings implementation.
