NuGet's implementation for interacting with feeds. Contains functionality for all feed types.
