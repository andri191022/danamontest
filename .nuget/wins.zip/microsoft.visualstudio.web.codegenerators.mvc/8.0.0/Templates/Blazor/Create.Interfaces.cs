using Microsoft.DotNet.Scaffolding.Shared.T4Templating;

namespace Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.Blazor
{
    public partial class Create : ITextTransformation
    {
    }
}

