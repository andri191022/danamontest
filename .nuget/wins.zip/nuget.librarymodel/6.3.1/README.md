NuGet's types and interfaces for understanding dependencies.
