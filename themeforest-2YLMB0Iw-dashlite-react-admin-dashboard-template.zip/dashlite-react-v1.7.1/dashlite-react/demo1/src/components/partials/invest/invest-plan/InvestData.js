export const investData = [
  {
    id: 1,
    pack: "Starter Plan",
    amount: "58",
    color: "default",
  },
  {
    id: 2,
    pack: "Silver Plan",
    amount: "18.49",
    color: "orange",
  },
  {
    id: 3,
    pack: "Diamond Plan",
    amount: "16",
    color: "success",
  },
  {
    id: 4,
    pack: "Platinum Plan",
    amount: "29",
    color: "pink",
  },
  {
    id: 5,
    pack: "Vibranium Plan",
    amount: "33",
    color: "azure",
  },
];

export const investDataSet2 = [
  {
    id: 1,
    pack: "Starter Plan",
    amount: "70",
    color: "default",
  },
  {
    id: 2,
    pack: "Silver Plan",
    amount: "32.49",
    color: "orange",
  },
  {
    id: 3,
    pack: "Diamond Plan",
    amount: "80",
    color: "success",
  },
  {
    id: 4,
    pack: "Platinum Plan",
    amount: "16",
    color: "pink",
  },
  {
    id: 5,
    pack: "Vibranium Plan",
    amount: "20",
    color: "azure",
  },
];
export const investDataSet3 = [
  {
    id: 1,
    pack: "Starter Plan",
    amount: "90",
    color: "default",
  },
  {
    id: 2,
    pack: "Silver Plan",
    amount: "50.49",
    color: "orange",
  },
  {
    id: 3,
    pack: "Diamond Plan",
    amount: "32",
    color: "success",
  },
  {
    id: 4,
    pack: "Platinum Plan",
    amount: "16",
    color: "pink",
  },
  {
    id: 5,
    pack: "Vibranium Plan",
    amount: "10",
    color: "azure",
  },
];

export const investDataSet4 = [
  {
    id: 1,
    pack: "Starter Plan",
    amount: "58",
    color: "default",
  },
  {
    id: 2,
    pack: "Silver Plan",
    amount: "18.49",
    color: "orange",
  },
  {
    id: 3,
    pack: "Diamond Plan",
    amount: "16",
    color: "success",
  },
  {
    id: 4,
    pack: "Platinum Plan",
    amount: "29",
    color: "pink",
  },
  {
    id: 5,
    pack: "Vibranium Plan",
    amount: "33",
    color: "azure",
  },
];
